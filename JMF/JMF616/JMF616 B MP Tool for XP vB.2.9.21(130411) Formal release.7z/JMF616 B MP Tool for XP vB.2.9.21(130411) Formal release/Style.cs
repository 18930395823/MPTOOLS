[Main]
Left=183
Top=13
Width=1083
Height=833
[Style]
PortPanel0=Left 0 Top 0 Width 249 Height 129
PortPanel1=Left 0 Top 129 Width 249 Height 129
PortPanel2=Left 0 Top 258 Width 249 Height 129
PortPanel3=Left 249 Top 0 Width 249 Height 129
PortPanel4=Left 249 Top 129 Width 249 Height 129
PortPanel5=Left 249 Top 258 Width 249 Height 129
PortPanel6=Left 498 Top 0 Width 249 Height 129
PortPanel7=Left 498 Top 129 Width 249 Height 129
PortPanel8=Left 498 Top 258 Width 249 Height 129
PortPanel9=Left 747 Top 0 Width 249 Height 129
PortPanel10=Left 747 Top 129 Width 249 Height 129
PortPanel11=Left 747 Top 258 Width 249 Height 129
