[Main]
Left=107
Top=3
Width=1164
Height=733
[Style]
PortPanel0=Left 0 Top 0 Width 249 Height 65
PortPanel1=Left 0 Top 65 Width 249 Height 65
PortPanel2=Left 0 Top 130 Width 249 Height 65
PortPanel3=Left 0 Top 195 Width 249 Height 65
PortPanel4=Left 0 Top 260 Width 249 Height 65
PortPanel5=Left 0 Top 325 Width 249 Height 65
PortPanel6=Left 249 Top 0 Width 249 Height 65
PortPanel7=Left 249 Top 65 Width 249 Height 65
PortPanel8=Left 498 Top 130 Width 249 Height 65
PortPanel9=Left 747 Top 0 Width 249 Height 65
PortPanel10=Left 747 Top 65 Width 249 Height 65
PortPanel11=Left 747 Top 130 Width 249 Height 65
