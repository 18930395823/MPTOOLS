[Main]
Left=0
Top=8
Width=1024
Height=715
[Style]
PortPanel0=Left 0 Top 0 Width 249 Height 65
PortPanel1=Left 0 Top 65 Width 249 Height 65
PortPanel2=Left 0 Top 130 Width 249 Height 65
PortPanel3=Left 0 Top 195 Width 249 Height 65
PortPanel4=Left 0 Top 260 Width 249 Height 65
PortPanel5=Left 0 Top 325 Width 249 Height 65
PortPanel6=Left 249 Top 0 Width 249 Height 65
PortPanel7=Left 249 Top 65 Width 249 Height 65
PortPanel8=Left 249 Top 130 Width 249 Height 65
PortPanel9=Left 249 Top 195 Width 249 Height 65
PortPanel10=Left 249 Top 260 Width 249 Height 65
PortPanel11=Left 249 Top 325 Width 249 Height 65
