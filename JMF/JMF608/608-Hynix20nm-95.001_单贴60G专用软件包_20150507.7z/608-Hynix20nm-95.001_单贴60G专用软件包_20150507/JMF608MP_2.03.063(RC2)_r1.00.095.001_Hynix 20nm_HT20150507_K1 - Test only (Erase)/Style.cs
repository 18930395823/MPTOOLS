[Main]
Left=118
Top=0
Width=1125
Height=784
[Style]
PortPanel0=Left -602 Top 0 Width 249 Height 129
PortPanel1=Left -602 Top 129 Width 249 Height 129
PortPanel2=Left -593 Top 194 Width 249 Height 129
PortPanel3=Left -353 Top 0 Width 249 Height 129
PortPanel4=Left -353 Top 129 Width 249 Height 129
PortPanel5=Left -353 Top 258 Width 249 Height 129
PortPanel6=Left -104 Top 0 Width 249 Height 129
PortPanel7=Left -104 Top 129 Width 249 Height 129
PortPanel8=Left -87 Top 14 Width 249 Height 129
PortPanel9=Left -590 Top 10 Width 249 Height 129
PortPanel10=Left -336 Top 13 Width 249 Height 129
PortPanel11=Left 170 Top 15 Width 249 Height 129
PortPanel12=Left 394 Top 0 Width 249 Height 129
PortPanel13=Left 394 Top 129 Width 249 Height 129
PortPanel14=Left 394 Top 258 Width 249 Height 129
PortPanel15=Left 643 Top 0 Width 249 Height 129
PortPanel16=Left 643 Top 129 Width 249 Height 129
PortPanel17=Left 643 Top 258 Width 249 Height 129
PortPanel18=Left 892 Top 0 Width 249 Height 129
PortPanel19=Left 892 Top 129 Width 249 Height 129
PortPanel20=Left -88 Top 194 Width 249 Height 129
PortPanel21=Left -341 Top 194 Width 249 Height 129
