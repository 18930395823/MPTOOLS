[Main]
Left=154
Top=0
Width=1037
Height=751
[Style]
PortPanel0=Left -2 Top 0 Width 249 Height 129
PortPanel1=Left -2 Top 129 Width 249 Height 129
PortPanel2=Left -2 Top 258 Width 249 Height 129
PortPanel3=Left 247 Top 0 Width 249 Height 129
PortPanel4=Left 247 Top 129 Width 249 Height 129
PortPanel5=Left 247 Top 258 Width 249 Height 129
PortPanel6=Left 496 Top 0 Width 249 Height 129
PortPanel7=Left 496 Top 129 Width 249 Height 129
PortPanel8=Left 496 Top 258 Width 249 Height 129
PortPanel9=Left 745 Top 0 Width 249 Height 129
PortPanel10=Left 745 Top 129 Width 249 Height 129
PortPanel11=Left 745 Top 258 Width 249 Height 129
PortPanel12=Left 994 Top 0 Width 249 Height 129
PortPanel13=Left 994 Top 129 Width 249 Height 129
PortPanel14=Left 994 Top 258 Width 249 Height 129
PortPanel15=Left 1243 Top 0 Width 249 Height 129
PortPanel16=Left 12 Top 3 Width 249 Height 129
PortPanel17=Left 17 Top 150 Width 249 Height 129
