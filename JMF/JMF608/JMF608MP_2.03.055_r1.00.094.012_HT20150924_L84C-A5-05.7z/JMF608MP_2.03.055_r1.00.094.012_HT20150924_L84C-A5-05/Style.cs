[Main]
Left=3
Top=0
Width=1378
Height=764
[Style]
PortPanel0=Left 19 Top 9 Width 249 Height 129
PortPanel1=Left -55 Top 129 Width 249 Height 129
PortPanel2=Left 40 Top 85 Width 249 Height 129
PortPanel3=Left 194 Top 0 Width 249 Height 129
PortPanel4=Left 194 Top 129 Width 249 Height 129
PortPanel5=Left 194 Top 258 Width 249 Height 129
PortPanel6=Left 443 Top 0 Width 249 Height 129
PortPanel7=Left 443 Top 129 Width 249 Height 129
PortPanel8=Left 443 Top 258 Width 249 Height 129
PortPanel9=Left 692 Top 0 Width 249 Height 129
PortPanel10=Left 692 Top 129 Width 249 Height 129
PortPanel11=Left 692 Top 258 Width 249 Height 129
PortPanel12=Left 941 Top 0 Width 249 Height 129
PortPanel13=Left 941 Top 129 Width 249 Height 129
PortPanel14=Left 941 Top 258 Width 249 Height 129
PortPanel15=Left 1190 Top 0 Width 249 Height 129
