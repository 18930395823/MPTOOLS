[Main]
Left=71
Top=0
Width=1227
Height=744
[Style]
PortPanel0=Left 10 Top 17 Width 249 Height 129
PortPanel1=Left 296 Top 19 Width 249 Height 129
PortPanel2=Left 611 Top 24 Width 249 Height 129
PortPanel3=Left 897 Top 23 Width 249 Height 129
PortPanel4=Left 14 Top 191 Width 249 Height 129
PortPanel5=Left 298 Top 186 Width 249 Height 129
PortPanel6=Left 608 Top 193 Width 249 Height 129
PortPanel7=Left 899 Top 189 Width 249 Height 129
PortPanel8=Left 470 Top 234 Width 249 Height 129
PortPanel9=Left 719 Top -24 Width 249 Height 129
PortPanel10=Left 719 Top 105 Width 249 Height 129
PortPanel11=Left 719 Top 234 Width 249 Height 129
PortPanel12=Left 968 Top -24 Width 249 Height 129
PortPanel13=Left 968 Top 105 Width 249 Height 129
PortPanel14=Left 968 Top 234 Width 249 Height 129
PortPanel15=Left -28 Top -24 Width 249 Height 129
