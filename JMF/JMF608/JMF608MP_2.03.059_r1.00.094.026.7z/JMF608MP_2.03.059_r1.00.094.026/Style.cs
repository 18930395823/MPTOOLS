[Main]
Left=79
Top=20
Width=1208
Height=728
[Style]
PortPanel0=Left -2 Top -2 Width 249 Height 129
PortPanel1=Left 0 Top 0 Width 249 Height 129
PortPanel2=Left -10 Top 254 Width 249 Height 129
PortPanel3=Left 239 Top -4 Width 249 Height 129
PortPanel4=Left 0 Top 0 Width 249 Height 129
PortPanel5=Left 0 Top 0 Width 249 Height 129
PortPanel6=Left 488 Top -4 Width 249 Height 129
PortPanel7=Left 488 Top 125 Width 249 Height 129
PortPanel8=Left 488 Top 254 Width 249 Height 129
PortPanel9=Left 737 Top -4 Width 249 Height 129
PortPanel10=Left 737 Top 125 Width 249 Height 129
PortPanel11=Left 737 Top 254 Width 249 Height 129
PortPanel12=Left 996 Top 0 Width 249 Height 129
PortPanel13=Left 996 Top 129 Width 249 Height 129
PortPanel14=Left 996 Top 258 Width 249 Height 129
PortPanel15=Left 1245 Top 0 Width 249 Height 129
