[Main]
Left=58
Top=35
Width=1251
Height=698
[Style]
PortPanel0=Left -4 Top 0 Width 249 Height 129
PortPanel1=Left -4 Top 129 Width 249 Height 129
PortPanel2=Left 245 Top 0 Width 249 Height 129
PortPanel3=Left 245 Top 129 Width 249 Height 129
PortPanel4=Left 494 Top 0 Width 249 Height 129
PortPanel5=Left 494 Top 129 Width 249 Height 129
PortPanel6=Left 743 Top 0 Width 249 Height 129
PortPanel7=Left 743 Top 129 Width 249 Height 129
PortPanel8=Left 992 Top 0 Width 249 Height 129
PortPanel9=Left 992 Top 129 Width 249 Height 129
PortPanel10=Left 1241 Top 0 Width 249 Height 129
PortPanel11=Left 36 Top 44 Width 249 Height 129
PortPanel12=Left 996 Top 0 Width 249 Height 129
PortPanel13=Left 996 Top 129 Width 249 Height 129
PortPanel14=Left 996 Top 258 Width 249 Height 129
PortPanel15=Left 1245 Top 0 Width 249 Height 129
