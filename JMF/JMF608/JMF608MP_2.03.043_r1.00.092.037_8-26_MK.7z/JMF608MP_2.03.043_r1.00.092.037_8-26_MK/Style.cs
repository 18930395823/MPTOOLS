[Main]
Left=3
Top=0
Width=1386
Height=747
[Style]
PortPanel0=Left 1 Top 6 Width 249 Height 129
PortPanel1=Left 0 Top 152 Width 249 Height 129
PortPanel2=Left 517 Top 154 Width 249 Height 129
PortPanel3=Left 34 Top 19 Width 249 Height 129
PortPanel4=Left 229 Top -6 Width 249 Height 129
PortPanel5=Left 229 Top 123 Width 249 Height 129
PortPanel6=Left 229 Top 252 Width 249 Height 129
PortPanel7=Left 229 Top 381 Width 249 Height 129
PortPanel8=Left 478 Top -6 Width 249 Height 129
PortPanel9=Left 478 Top 123 Width 249 Height 129
PortPanel10=Left 478 Top 252 Width 249 Height 129
PortPanel11=Left 478 Top 381 Width 249 Height 129
PortPanel12=Left 1063 Top 150 Width 249 Height 129
PortPanel13=Left 788 Top 151 Width 249 Height 129
PortPanel14=Left 727 Top 252 Width 249 Height 129
PortPanel15=Left 727 Top 381 Width 249 Height 129
