[Main]
Left=106
Top=107
Width=1068
Height=586
[Style]
PortPanel0=Left -2 Top -2 Width 249 Height 129
PortPanel1=Left 21 Top 33 Width 249 Height 129
PortPanel2=Left -22 Top 236 Width 249 Height 129
PortPanel3=Left 227 Top -22 Width 249 Height 129
PortPanel4=Left 227 Top 107 Width 249 Height 129
PortPanel5=Left 227 Top 236 Width 249 Height 129
PortPanel6=Left 476 Top -22 Width 249 Height 129
PortPanel7=Left 476 Top 107 Width 249 Height 129
PortPanel8=Left 476 Top 236 Width 249 Height 129
PortPanel9=Left 725 Top -22 Width 249 Height 129
PortPanel10=Left -1 Top -4 Width 249 Height 129
PortPanel11=Left 725 Top 236 Width 249 Height 129
PortPanel12=Left 974 Top -22 Width 249 Height 129
PortPanel13=Left 974 Top 107 Width 249 Height 129
PortPanel14=Left 974 Top 236 Width 249 Height 129
PortPanel15=Left 1223 Top -22 Width 249 Height 129
PortPanel16=Left 1223 Top 107 Width 249 Height 129
PortPanel17=Left 1223 Top 236 Width 249 Height 129
PortPanel18=Left 1472 Top -22 Width 249 Height 129
PortPanel19=Left 1472 Top 107 Width 249 Height 129
