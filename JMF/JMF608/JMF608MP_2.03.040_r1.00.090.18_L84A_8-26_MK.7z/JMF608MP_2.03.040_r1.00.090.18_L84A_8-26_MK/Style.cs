[Main]
Left=260
Top=113
Width=1322
Height=851
[Style]
PortPanel0=Left -441 Top 0 Width 249 Height 129
PortPanel1=Left -441 Top 129 Width 249 Height 129
PortPanel2=Left -441 Top 258 Width 249 Height 129
PortPanel3=Left -192 Top 0 Width 249 Height 129
PortPanel4=Left -192 Top 129 Width 249 Height 129
PortPanel5=Left -192 Top 258 Width 249 Height 129
PortPanel6=Left 57 Top 0 Width 249 Height 129
PortPanel7=Left 57 Top 129 Width 249 Height 129
PortPanel8=Left 57 Top 258 Width 249 Height 129
PortPanel9=Left 306 Top 0 Width 249 Height 129
PortPanel10=Left 306 Top 129 Width 249 Height 129
PortPanel11=Left 306 Top 258 Width 249 Height 129
PortPanel12=Left 555 Top 0 Width 249 Height 129
PortPanel13=Left 555 Top 129 Width 249 Height 129
PortPanel14=Left 555 Top 258 Width 249 Height 129
PortPanel15=Left 804 Top 0 Width 249 Height 129
PortPanel16=Left 804 Top 129 Width 249 Height 129
PortPanel17=Left 804 Top 258 Width 249 Height 129
PortPanel18=Left 1053 Top 0 Width 249 Height 129
PortPanel19=Left 1053 Top 129 Width 249 Height 129
