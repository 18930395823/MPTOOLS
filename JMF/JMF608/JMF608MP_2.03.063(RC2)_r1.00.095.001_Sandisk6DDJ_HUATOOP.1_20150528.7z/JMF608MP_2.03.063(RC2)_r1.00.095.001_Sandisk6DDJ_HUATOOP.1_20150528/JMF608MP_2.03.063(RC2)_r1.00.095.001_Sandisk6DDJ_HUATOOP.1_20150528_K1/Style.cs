[Main]
Left=32
Top=0
Width=1296
Height=784
[Style]
PortPanel0=Left -6 Top -2 Width 249 Height 129
PortPanel1=Left -6 Top 127 Width 249 Height 129
PortPanel2=Left 72 Top -4 Width 249 Height 129
PortPanel3=Left 74 Top 387 Width 249 Height 129
PortPanel4=Left 243 Top -2 Width 249 Height 129
PortPanel5=Left 243 Top 127 Width 249 Height 129
PortPanel6=Left 243 Top 256 Width 249 Height 129
PortPanel7=Left 243 Top 385 Width 249 Height 129
PortPanel8=Left 492 Top -2 Width 249 Height 129
PortPanel9=Left 492 Top 127 Width 249 Height 129
PortPanel10=Left 492 Top 256 Width 249 Height 129
PortPanel11=Left 492 Top 385 Width 249 Height 129
PortPanel12=Left 741 Top -2 Width 249 Height 129
PortPanel13=Left 741 Top 127 Width 249 Height 129
PortPanel14=Left 741 Top 256 Width 249 Height 129
PortPanel15=Left 741 Top 385 Width 249 Height 129
PortPanel16=Left 990 Top -2 Width 249 Height 129
PortPanel17=Left 990 Top 127 Width 249 Height 129
PortPanel18=Left 990 Top 256 Width 249 Height 129
PortPanel19=Left 990 Top 385 Width 249 Height 129
PortPanel20=Left 73 Top 127 Width 249 Height 129
PortPanel21=Left 74 Top 257 Width 249 Height 129
